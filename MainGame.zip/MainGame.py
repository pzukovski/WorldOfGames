from Live import load_game, welcome

welcome("Paul")
load_game()